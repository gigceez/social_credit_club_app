package com.example.social_credit_app_club

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
